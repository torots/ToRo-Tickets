<?php
/*********************************************************************
    index.php
    
    Future site for helpdesk summary aka Dashboard.

    r h <p@torots.com>
    Copyright (c)  2006-2011 toroTS
    http://www.torots.com

    Released under the GNU General Public License WITHOUT ANY WARRANTY.
    See LICENSE.TXT for details.

    vim: expandtab sw=4 ts=4 sts=4:
    $Id: index.php,v 1.7 2011/11/10 14:52:32 root Exp $
**********************************************************************/
//Nothing for now...simply redirect to tickets page.
require_once('tickets.php');
?>
