<?
// version information //
$VER="v20100607a";

// general path //
$_CONF['path']		= 'C:/Inetpub/wwwroot/support/scp/reports/';

// include path //
$_CONF['inc']		= 'C:/Inetpub/wwwroot/support/scp/reports/inc/';

// log file //
$_CONF['logfile']	= 'C:/Inetpub/wwwroot/support/scp/reports/reports.log';

// table name //
$_CONF['tbl']		= 'reports';

// debug mode ( 0 = off, 1 = on )
$debug = '0';

// email rcpt //
// 19sep2007 : this is not used at this time. 
//$_CONF[email_to] = "admin@harborhomes.org";
//$_CONF[email_to] = "foop@harborhomes.org";
?>