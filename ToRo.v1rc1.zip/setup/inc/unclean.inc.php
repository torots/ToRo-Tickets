<h1>osTicket is already installed?</h1>
<p>Configuration file already changed - which could mean osTicket is already installed or the config file is unclean. If you are trying to upgrade the system then <a href="upgrade.php" >click here</a>.</p>
<p>If you believe this is in error, please try replacing the config file with a unchanged template copy and try again or get technical help from developers.</p>
<br>
<br><br>
