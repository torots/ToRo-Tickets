<h1>osTicket requires PHP 4.3 or better</h1>
<p>You should be running PHP5 at this day and age.</p>
<p>If this is part of a hosting package, please start looking for a better host.</p>
<p>Thank you and good luck with the upgrade</p>
<br/>
<br/><div align="center"><b><a href="">Done? Continue&raquo;</a></b></div>

  
