<?php
if(defined('TOROPVTLTD') && is_object($user))
{
	include_once(INCLUDE_DIR.'staff/autoclose.inc.php');
}
?> 
