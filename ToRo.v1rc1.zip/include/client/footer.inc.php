 <div style="clear:both"></div>
 </div>
 <div id="footer">Copyright &copy; <?php
   $startd = '2011';
   $currd = date(Y);

   if ($startd == $currd) {
    echo "$startd";
   }
   else {
    echo $startd.'-'.$currd;
   }
  ?> torots.com. All rights reserved</div>
  <div align="center">
   <!-- As a show of support, we ask that you leave powered by osTicket link to help spread the word. Thank you! -->
   <!--<a id="powered_by" href="http://torots.com"><img src="./images/poweredby.jpg" width="126" height="23" alt="A branch of osTicket"></a></div>i-->
   <a id="powered_by" href="http://torots.com"><img src="./images/changeToPoweredBy.jpg" alt="A branch of osTicket"></a>
  </div>
 </div>
</body>
</html>
