<?php
/*

 toro Ticketing System
 Admin Panel -> Dashboard -> Reports

*/

if(!defined('OSTADMININC') || !$thisuser->isadmin()) die(translate("TEXT_ACCESS_DENIED"));

?>
<font color=red>This page is only available in the Pro version.  Please contact sales@torots.com for information on purchasing the reporting module or a support contract.</font><br /><br />
See a demo of the reporting module here:<br /> <a href='http://torots.com/dev/scp/reports.php'>Reports Module</a>
